﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TrangDangKy
{
    public partial class DangKy : Form
    {
        public DangKy()
        {
            InitializeComponent();
        }

        private void btdangky_Click(object sender, EventArgs e)
        {
            if (tbhoten.Text == "")
            {
                MessageBox.Show("You have not entered your full name!", "notification", MessageBoxButtons.OK, MessageBoxIcon.Information);
                tbhoten.Focus();
            }
            else if (tbtennguoidung.Text == "")
            {
                MessageBox.Show("You have not entered a username!", "notification", MessageBoxButtons.OK, MessageBoxIcon.Information);
                tbtennguoidung.Focus();
            }
            else if (tbmatkhaunguoidung.Text == "")
            {
                MessageBox.Show("You have not entered the user password!", "notification", MessageBoxButtons.OK, MessageBoxIcon.Information);
                tbmatkhaunguoidung.Focus();
            }
            else if (tbxacnhanmatkhau.Text == "")
            {
                MessageBox.Show("You have not confirmed the user password!", "notification", MessageBoxButtons.OK, MessageBoxIcon.Information);
                tbxacnhanmatkhau.Focus();
            }
            else if (tbmatkhaunguoidung.Text != tbxacnhanmatkhau.Text)
            {
                MessageBox.Show("User password and user password confirmation are not the same!", "notification", MessageBoxButtons.OK, MessageBoxIcon.Information);
                tbxacnhanmatkhau.Focus();
                tbxacnhanmatkhau.SelectAll();
            }
        }
    }
}
