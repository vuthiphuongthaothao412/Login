﻿namespace TrangDangNhap
{
    partial class DangKy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.tbxacnhanmatkhau = new System.Windows.Forms.TextBox();
            this.tbmatkhaunguoidung = new System.Windows.Forms.TextBox();
            this.tbhoten = new System.Windows.Forms.TextBox();
            this.tbtennguoidung = new System.Windows.Forms.TextBox();
            this.tbemail = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btdangky = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btdongdangky = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(107, 88);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 1);
            this.panel1.TabIndex = 37;
            // 
            // tbxacnhanmatkhau
            // 
            this.tbxacnhanmatkhau.BackColor = System.Drawing.Color.White;
            this.tbxacnhanmatkhau.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxacnhanmatkhau.Location = new System.Drawing.Point(166, 328);
            this.tbxacnhanmatkhau.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbxacnhanmatkhau.Multiline = true;
            this.tbxacnhanmatkhau.Name = "tbxacnhanmatkhau";
            this.tbxacnhanmatkhau.Size = new System.Drawing.Size(210, 19);
            this.tbxacnhanmatkhau.TabIndex = 32;
            // 
            // tbmatkhaunguoidung
            // 
            this.tbmatkhaunguoidung.BackColor = System.Drawing.Color.White;
            this.tbmatkhaunguoidung.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbmatkhaunguoidung.Location = new System.Drawing.Point(166, 292);
            this.tbmatkhaunguoidung.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbmatkhaunguoidung.Multiline = true;
            this.tbmatkhaunguoidung.Name = "tbmatkhaunguoidung";
            this.tbmatkhaunguoidung.Size = new System.Drawing.Size(210, 19);
            this.tbmatkhaunguoidung.TabIndex = 33;
            // 
            // tbhoten
            // 
            this.tbhoten.BackColor = System.Drawing.Color.White;
            this.tbhoten.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbhoten.Location = new System.Drawing.Point(166, 168);
            this.tbhoten.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbhoten.Multiline = true;
            this.tbhoten.Name = "tbhoten";
            this.tbhoten.Size = new System.Drawing.Size(210, 19);
            this.tbhoten.TabIndex = 34;
            // 
            // tbtennguoidung
            // 
            this.tbtennguoidung.BackColor = System.Drawing.Color.White;
            this.tbtennguoidung.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbtennguoidung.Location = new System.Drawing.Point(166, 249);
            this.tbtennguoidung.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbtennguoidung.Multiline = true;
            this.tbtennguoidung.Name = "tbtennguoidung";
            this.tbtennguoidung.Size = new System.Drawing.Size(210, 19);
            this.tbtennguoidung.TabIndex = 35;
            // 
            // tbemail
            // 
            this.tbemail.BackColor = System.Drawing.Color.White;
            this.tbemail.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbemail.Location = new System.Drawing.Point(166, 209);
            this.tbemail.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbemail.Multiline = true;
            this.tbemail.Name = "tbemail";
            this.tbemail.Size = new System.Drawing.Size(210, 19);
            this.tbemail.TabIndex = 36;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(66, 93);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(344, 17);
            this.label7.TabIndex = 31;
            this.label7.Text = "Create your account. It\'s free and only takes a minute\r\n";
            // 
            // btdangky
            // 
            this.btdangky.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.btdangky.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btdangky.Location = new System.Drawing.Point(40, 376);
            this.btdangky.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btdangky.Name = "btdangky";
            this.btdangky.Size = new System.Drawing.Size(336, 44);
            this.btdangky.TabIndex = 30;
            this.btdangky.Text = "REGISTER NOW\r\n";
            this.btdangky.UseVisualStyleBackColor = false;
            this.btdangky.Click += new System.EventHandler(this.btdangky_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(36, 325);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(124, 22);
            this.label6.TabIndex = 27;
            this.label6.Text = "Confirm password\r\n";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(36, 209);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 22);
            this.label5.TabIndex = 29;
            this.label5.Text = "E-mail";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(36, 292);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 22);
            this.label4.TabIndex = 28;
            this.label4.Text = "Password";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(36, 249);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 22);
            this.label3.TabIndex = 26;
            this.label3.Text = "Username";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(36, 165);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 22);
            this.label2.TabIndex = 25;
            this.label2.Text = "Fullname";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.LightGoldenrodYellow;
            this.label1.Location = new System.Drawing.Point(148, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(132, 33);
            this.label1.TabIndex = 24;
            this.label1.Text = "REGISTER";
            // 
            // btdongdangky
            // 
            this.btdongdangky.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.btdongdangky.Location = new System.Drawing.Point(40, 427);
            this.btdongdangky.Name = "btdongdangky";
            this.btdongdangky.Size = new System.Drawing.Size(336, 41);
            this.btdongdangky.TabIndex = 38;
            this.btdongdangky.Text = "CLOSE REGISTER";
            this.btdongdangky.UseVisualStyleBackColor = false;
            this.btdongdangky.Click += new System.EventHandler(this.btdongdangky_Click);
            // 
            // DangKy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleVioletRed;
            this.ClientSize = new System.Drawing.Size(436, 500);
            this.Controls.Add(this.btdongdangky);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tbxacnhanmatkhau);
            this.Controls.Add(this.tbmatkhaunguoidung);
            this.Controls.Add(this.tbhoten);
            this.Controls.Add(this.tbtennguoidung);
            this.Controls.Add(this.tbemail);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btdangky);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "DangKy";
            this.Text = "DangKy";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox tbxacnhanmatkhau;
        private System.Windows.Forms.TextBox tbmatkhaunguoidung;
        private System.Windows.Forms.TextBox tbhoten;
        private System.Windows.Forms.TextBox tbtennguoidung;
        private System.Windows.Forms.TextBox tbemail;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btdangky;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btdongdangky;
    }
}