﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TrangDangNhap
{
    public partial class DangKy : Form
    {
        public DangKy()
        {
            InitializeComponent();
        }
        private void btdangky_Click(object sender, EventArgs e)
        {
            if (tbhoten.Text == "")
            {
                MessageBox.Show("You have not entered your full name!", "notification", MessageBoxButtons.OK, MessageBoxIcon.Information);
                tbhoten.Focus();
            }
            else if (tbtennguoidung.Text == "")
            {
                MessageBox.Show("You have not entered a username!", "notification", MessageBoxButtons.OK, MessageBoxIcon.Information);
                tbtennguoidung.Focus();
            }
            else if (tbmatkhaunguoidung.Text == "")
            {
                MessageBox.Show("You have not entered the user password!", "notification", MessageBoxButtons.OK, MessageBoxIcon.Information);
                tbmatkhaunguoidung.Focus();
            }
            else if (tbxacnhanmatkhau.Text == "")
            {
                MessageBox.Show("You have not confirmed the user password!", "notification", MessageBoxButtons.OK, MessageBoxIcon.Information);
                tbxacnhanmatkhau.Focus();
            }
            // xác định mật khẩu người dùng
            else if (tbmatkhaunguoidung.Text != tbxacnhanmatkhau.Text)
            {
                MessageBox.Show("The user password and user password confirmation must be the same", "notification", MessageBoxButtons.OK, MessageBoxIcon.Information);
                tbxacnhanmatkhau.Focus();
                tbxacnhanmatkhau.SelectAll();
            }
            else
            {
                SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-GV3V87E;Initial Catalog=NhanVien;Integrated Security=True");
                SqlCommand cmd = new SqlCommand(@"INSERT INTO [dbo].[NguoiDungHeThong] (TaiKhoan,MatKhau,Email_Address,Fullname) VALUES
                ('" + tbtennguoidung.Text + "', '" + tbmatkhaunguoidung.Text + "', '" + tbemail.Text + "', '" + tbhoten.Text + "')", con);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Register successfully");
            }
            
        }
        private void btdongdangky_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
