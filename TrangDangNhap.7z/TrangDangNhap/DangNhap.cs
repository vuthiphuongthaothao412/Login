﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TrangDangNhap
{
    public partial class DangNhap : Form
    {
        public DangNhap()
        {
            InitializeComponent();
        }

        private void btdangnhap_Click(object sender, EventArgs e)
        {
            //this.Hide();
            //TrangChu ss = new TrangChu();
            //ss.Show();
            SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-GV3V87E;Initial Catalog=NhanVien;Integrated Security=True");
            try
            {
                conn.Open();
                string taikhoan = tbtentaikhoan.Text;
                string matkhau = tbmatkhau.Text;
                string sql = "select *from NguoiDungHeThong where TaiKhoan='" + taikhoan + "' and MatKhau='" + matkhau + "'";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader dta = cmd.ExecuteReader();
                if(dta.Read()==true)
                {
                    MessageBox.Show("Login to your account successfully", "notification", MessageBoxButtons.OK,MessageBoxIcon.Information);
                    this.Hide();
                    TrangChu ss = new TrangChu();
                    ss.Show();
                }
                else
                {
                    MessageBox.Show("Login with wrong username or password", "notification", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }    
            }
            catch (Exception ex)
            {
                MessageBox.Show("Connection errors");
                throw ex;
            }
        }
        private void btthoat_Click(object sender, EventArgs e)
        {
            //Application.Exit();
            //this.Close();
            DialogResult tb = MessageBox.Show("Do you really want to log out?", "notification", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (tb == DialogResult.OK)
                this.Close();

        }

        private void cb_Show_Hide_CheckedChanged(object sender, EventArgs e)
        {
            if(cb_Show_Hide.Checked)
            {
                tbmatkhau.UseSystemPasswordChar = true;
            }
            else
            {
                tbmatkhau.UseSystemPasswordChar = false;
            }    
        }
        private void linkDangky_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            DangKy  add = new DangKy ();
            add.Show();
            this.Hide();
        }
    }
}
