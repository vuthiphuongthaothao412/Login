﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

namespace TrangDangNhap
{
    class DangKyNguoiDung
    {
        private string Fullname, Usename, Password, Email;

        public DangKyNguoiDung()
        {
            Fullname = "";
            Usename = "";
            Password = "";
            Email = "";
        }
        public DangKyNguoiDung(string hoten, string tk, string mk, string mail)
        {
            Fullname = hoten;
            Usename = tk;
            Password = mk;
            Email = mail;
        }

    }
}
